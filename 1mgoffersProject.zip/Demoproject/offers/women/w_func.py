def w_offer(x):
    return (x-(x*0.5))