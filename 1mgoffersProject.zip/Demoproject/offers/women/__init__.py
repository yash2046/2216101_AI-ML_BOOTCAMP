wmain='''Welcome to Women's Multi-Vitamin Catogory
We have 50% discount today'''