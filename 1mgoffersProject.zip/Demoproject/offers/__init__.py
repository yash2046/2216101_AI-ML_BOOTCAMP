main='''Welcome to TATA 1mg.com
Best Offers available DAILY!!!
'''
main1="Thanks for using our Website"