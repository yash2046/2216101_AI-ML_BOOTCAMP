import offers as off
import offers.allopathy as all
from offers.allopathy import allo_func as all1
import offers.covid as c
from offers.covid import cov_func as c1
import offers.women as w
from offers.women import w_func as w1
import offers.location as l
from offers.location import loc_func as l1
print(off.main)
w_dict={'revital':345,'Women Multi vitamin':995,'power gummies':1020}
a_dict={'Dr.Reckweg':180,'Rabiprime':55,'Cinoflex':148}
c_dict={'Covid19SelfTestKit':250,'JumaoOxygenConcentrator':85000,'DaburChyawanprash':220}
print("--------------MEDICINES AVAILABLE ARE--------------")
print("***Women's Multi-Vitamin Catogory***")
for i,j in w_dict.items():
    print(i,j)
print("-------------------")
print("***Allopathy Catogory***")
for x,y in a_dict.items():
    print(x,y)
print("-------------------")
print("***Covid-Essentials Catogory***")
for r,s in c_dict.items():
    print(r,s)
print("---------------------------------------------------------")
med=input("Enter Medicine Name:")
loca=input("Enter location:")
if(med=='revital' and loca=='wgl'):
    print(w.wmain)
    print(l.lmain)
    p1=w_dict['revital']
    print("Actual Price is:",p1)
    print("Offer Price is:",(w1.w_offer(p1)-l1.l_offer(p1)))
if(med=='revital' and loca!='wgl'):
    print(w.wmain)
    p2=w_dict['revital']
    print("Actual Price is:",p2)
    print("Offer Price is:",(w1.w_offer(p2)))
if(med=='Women Multi vitamin' and loca=='wgl'):
    print(w.wmain)
    print(l.lmain)
    p3=w_dict['Women Multi vitamin']
    print("Actual Price is:",p3)
    print("Offer Price is:",(w1.w_offer(p3)-l1.l_offer(p3)))
if(med=='Women Multi vitamin' and loca!='wgl'):
    print(w.wmain)
    p4=w_dict['Women Multi vitamin']
    print("Actual Price is:",p4)
    print("Offer Price is:",(w1.w_offer(p4)))
if(med=='power gummies' and loca=='wgl'):
    print(w.wmain)
    print(l.lmain)
    p5=w_dict['power gummies']
    print("Actual Price is:",p5)
    print("Offer Price is:",(w1.w_offer(p5)-l1.l_offer(p5)))
if(med=='power gummies' and loca!='wgl'):
    print(w.wmain)
    p6=w_dict['power gummies']
    print("Actual Price is:",p6)
    print("Offer Price is:",(w1.w_offer(p6)))
if(med=='Dr.Reckweg' and loca=='wgl'):
    print(all.amain)
    print(l.lmain)
    p7=a_dict['Dr.Reckweg']
    print("Actual Price is:",p7)
    print("Offer Price is:",(all1.a_offer(p7)-l1.l_offer(p7)))
if(med=='Dr.Reckweg' and loca!='wgl'):
    print(all.amain)
    p8=a_dict['Dr.Reckweg']
    print("Actual Price is:",p8)
    print("Offer Price is:",(all1.a_offer(p8)))
if(med=='Rabiprime' and loca=='wgl'):
    print(all.amain)
    print(l.lmain)
    p9=a_dict['Rabiprime']
    print("Actual Price is:",p9)
    print("Offer Price is:",(all1.a_offer(p9)-l1.l_offer(p9)))
if(med=='Rabiprime' and loca!='wgl'):
    print(all.amain)
    p10=a_dict['Rabiprime']
    print("Actual Price is:",p10)
    print("Offer Price is:",(all1.a_offer(p10)))
if(med=='Cinoflex' and loca=='wgl'):
    print(all.amain)
    print(l.lmain)
    p11=a_dict['Cinoflex']
    print("Actual Price is:",p11)
    print("Offer Price is:",(all1.a_offer(p11)-l1.l_offer(p11)))
if(med=='Cinoflex' and loca!='wgl'):
    print(all.amain)
    p12=a_dict['Cinoflex']
    print("Actual Price is:",p12)
    print("Offer Price is:",(all1.a_offer(p12)))
if(med=='Covid19SelfTestKit' and loca=='wgl'):
    print(c.cmain)
    print(l.lmain)
    p13=c_dict['Covid19SelfTestKit']
    print("Actual Price is:",p13)
    print("Offer Price is:",(c1.c_offer(p13)-l1.l_offer(p13)))
if(med=='Covid19SelfTestKit' and loca!='wgl'):
    print(c.cmain)
    p14=c_dict['Covid19SelfTestKit']
    print("Actual Price is:",p14)
    print("Offer Price is:",(c1.c_offer(p14)))
if(med=='JumaoOxygenConcentrator' and loca=='wgl'):
    print(c.cmain)
    print(l.lmain)
    p15=c_dict['JumaoOxygenConcentrator']
    print("Actual Price is:",p15)
    print("Offer Price is:",(c1.c_offer(p15)-l1.l_offer(p15)))
if(med=='JumaoOxygenConcentrator' and loca!='wgl'):
    print(c.cmain)
    p16=c_dict['JumaoOxygenConcentrator']
    print("Actual Price is:",p16)
    print("Offer Price is:",(c1.c_offer(p16)))
if(med=='DaburChyawanprash' and loca=='wgl'):
    print(c.cmain)
    print(l.lmain)
    p17=c_dict['DaburChyawanprash']
    print("Actual Price is:",p17)
    print("Offer Price is:",(c1.c_offer(p17)-l1.l_offer(p17)))
if(med=='DaburChyawanprash' and loca!='wgl'):
    print(c.cmain)
    p18=c_dict['DaburChyawanprash']
    print("Actual Price is:",p18)
    print("Offer Price is:",(c1.c_offer(p18)))
if(med not in w_dict.keys() and med not in a_dict.keys() and med not in c_dict.keys()):
    print("OOPS!!Medicine Not Available\nOR\nCheck The Name and Try Later")
print(off.main1)