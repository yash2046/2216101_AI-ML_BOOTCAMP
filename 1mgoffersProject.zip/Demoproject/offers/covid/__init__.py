cmain='''Welcome to Covid-Essentials Catogory
We have 15% discount today'''