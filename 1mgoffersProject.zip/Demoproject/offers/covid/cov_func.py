def c_offer(x):
    return (x-(x*0.15))