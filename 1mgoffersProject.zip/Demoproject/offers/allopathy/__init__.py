amain='''Welcome to allopathy Catogory
We have 20% discount today'''
