def a_offer(x):
    return (x-(x*0.2))