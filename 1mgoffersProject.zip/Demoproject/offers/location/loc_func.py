def l_offer(x):
    return (x*0.05)