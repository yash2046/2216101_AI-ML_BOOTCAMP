lmain='''5% discount for users in Warangal
Offer Closes soon'''
